import { expect, test } from '@playwright/test'
import {
    ADMIN, API, bearer, dependente, firstChoiceAnswer, loginToken, newSession, nextIp, psicologo,
    questions, register, saoPauloDate, uniq,
} from './helpers'

// Testes de API com a aplicação rodando (fluxos que o front ainda não implementa).
// Cada chamada usa um X-Forwarded-For próprio para o limite de 5/min por IP não interferir.

test.describe('cadastro', () => {
    test('adulto: 201 com id, nome e e-mail', async ({ request }) => {
        const u = dependente({ email: `${uniq('Dep')}@PLAD.dev` })
        const res = await register(request, u)
        expect(res.status()).toBe(201)
        const body = await res.json()
        expect(body.id).toBeGreaterThan(0)
        expect(body.email).toBe(u.email.toLowerCase())
    })

    test('quem faz 18 amanhã: 400 VALIDATION_ERROR em birth_date', async ({ request }) => {
        const res = await register(request, dependente({ birth_date: saoPauloDate(18, 1) }))
        expect(res.status()).toBe(400)
        const body = await res.json()
        expect(body.code).toBe('VALIDATION_ERROR')
        expect(body.errors.map((e: { field: string }) => e.field)).toContain('birth_date')
    })

    test('quem faz 18 hoje: 201', async ({ request }) => {
        const res = await register(request, dependente({ birth_date: saoPauloDate(18, 0) }))
        expect(res.status()).toBe(201)
    })

    test('type_user admin: 400 INVALID_REGISTRATION', async ({ request }) => {
        const res = await register(request, dependente({ type_user: 'admin' }))
        expect(res.status()).toBe(400)
        expect((await res.json()).code).toBe('INVALID_REGISTRATION')
    })

    test('e-mail repetido em maiúsculas: 409 EMAIL_IN_USE', async ({ request }) => {
        const u = dependente()
        expect((await register(request, u)).status()).toBe(201)
        const res = await register(request, { ...u, email: u.email.toUpperCase() })
        expect(res.status()).toBe(409)
        expect((await res.json()).code).toBe('EMAIL_IN_USE')
    })

    test('CRP "06/123456" e "06 / 123456" são o mesmo registro: duplicado 400', async ({ request }) => {
        const base = psicologo()
        const n = base.crm_crp_number!.split('/')[1]
        expect((await register(request, { ...base, crm_crp_number: `06/${n}` })).status()).toBe(201)
        const res = await register(request, psicologo({ crm_crp_number: `06 / ${n}` }))
        expect(res.status()).toBe(400)
        expect((await res.json()).code).toBe('INVALID_REGISTRATION')
    })

    test('psicólogo sem número de registro: 400', async ({ request }) => {
        const res = await register(request, psicologo({ crm_crp_number: undefined }))
        expect(res.status()).toBe(400)
    })
})

test.describe('login', () => {
    test('senha errada e e-mail inexistente respondem igual (não revela se a conta existe)', async ({ request }) => {
        const u = dependente()
        await register(request, u)
        const wrong = await request.post(`${API}/auth/login`, { data: { email: u.email, password: 'senha-errada-999' }, headers: { 'X-Forwarded-For': nextIp() } })
        const unknown = await request.post(`${API}/auth/login`, { data: { email: `${uniq('nao-existe')}@plad.dev`, password: 'senha-errada-999' }, headers: { 'X-Forwarded-For': nextIp() } })
        expect(wrong.status()).toBe(401)
        expect(unknown.status()).toBe(401)
        const a = await wrong.json()
        const b = await unknown.json()
        expect({ code: a.code, message: a.message, errors: a.errors }).toEqual({ code: b.code, message: b.message, errors: b.errors })
        expect(a.code).toBe('INVALID_CREDENTIALS')
    })

    test('6ª tentativa do mesmo IP: 429 RATE_LIMITED com Retry-After', async ({ request }) => {
        const ip = nextIp()
        const statuses: number[] = []
        let last = null
        for (let i = 0; i < 6; i++) {
            last = await request.post(`${API}/auth/login`, { data: { email: `${uniq('rl')}@plad.dev`, password: 'senha-errada-999' }, headers: { 'X-Forwarded-For': ip } })
            statuses.push(last.status())
        }
        expect(statuses).toEqual([401, 401, 401, 401, 401, 429])
        expect(Number(last!.headers()['retry-after'])).toBeGreaterThan(0)
        expect((await last!.json()).code).toBe('RATE_LIMITED')
    })
})

test.describe('/me e erros', () => {
    test('/me do dependente: sem real_name, com has_triage', async ({ request }) => {
        const { token, user } = await newSession(request, dependente())
        const res = await request.get(`${API}/me`, { headers: bearer(token) })
        expect(res.status()).toBe(200)
        const me = await res.json()
        expect(me.email).toBe(user.email)
        expect(me.type_user).toBe('dependente')
        expect(me.has_triage).toBe(false)
        expect(me.real_name).toBeNull()
        expect(me.crm_crp_number).toBeNull()
    })

    test('/me do psicólogo: credencial e is_validated=false', async ({ request }) => {
        const p = psicologo()
        const { token } = await newSession(request, p)
        const me = await (await request.get(`${API}/me`, { headers: bearer(token) })).json()
        expect(me.type_user).toBe('psicologo')
        expect(me.real_name).toBe(p.real_name)
        expect(me.credential_type).toBe('CRP')
        expect(me.crm_crp_number).toBe(p.crm_crp_number!.replace(/\W/g, '').toUpperCase())
        expect(me.is_validated).toBe(false)
        expect(me.has_triage).toBeNull()
    })

    test('sem token: 401 UNAUTHORIZED em JSON', async ({ request }) => {
        const res = await request.get(`${API}/me`, { headers: { 'X-Forwarded-For': nextIp() } })
        expect(res.status()).toBe(401)
        expect(res.headers()['content-type']).toContain('application/json')
        const body = await res.json()
        expect(body.code).toBe('UNAUTHORIZED')
        expect(typeof body.message).toBe('string')
        expect(Array.isArray(body.errors)).toBe(true)
    })

    test('X-Request-Id é devolvido (o enviado, se válido; senão um gerado)', async ({ request }) => {
        const mine = `e2e-${uniq('rid')}`
        const echoed = await request.get(`${API}/me`, { headers: { 'X-Request-Id': mine, 'X-Forwarded-For': nextIp() } })
        expect(echoed.headers()['x-request-id']).toBe(mine)
        const generated = await request.get(`${API}/me`, { headers: { 'X-Request-Id': 'inválido com espaços!', 'X-Forwarded-For': nextIp() } })
        expect(generated.headers()['x-request-id']).toMatch(/^[0-9a-f-]{36}$/)
    })
})

test.describe('triagem', () => {
    test('perguntas não oferecem AGE_UNDER_18', async ({ request }) => {
        const { token } = await newSession(request, dependente())
        const qs = await questions(request, token)
        expect(qs.length).toBeGreaterThan(0)
        const codes = qs.flatMap((q) => q.options.map((o) => o.code))
        expect(codes).not.toContain('AGE_UNDER_18')
        const sorted = [...qs].sort((a, b) => a.display_order - b.display_order)
        expect(qs.map((q) => q.id)).toEqual(sorted.map((q) => q.id))
    })

    test('POST 201, segundo POST 409, PUT 200', async ({ request }) => {
        const { token } = await newSession(request, dependente())
        const answers = [firstChoiceAnswer(await questions(request, token))]
        const post = await request.post(`${API}/triage`, { data: { answers }, headers: bearer(token) })
        expect(post.status()).toBe(201)
        expect((await post.json()).answers).toHaveLength(1)

        const again = await request.post(`${API}/triage`, { data: { answers }, headers: bearer(token) })
        expect(again.status()).toBe(409)
        expect((await again.json()).code).toBe('TRIAGE_ALREADY_EXISTS')

        const put = await request.put(`${API}/triage`, { data: { answers }, headers: bearer(token) })
        expect(put.status()).toBe(200)
    })

    test('POST vazio: 204 e nada gravado (ainda dá para enviar depois)', async ({ request }) => {
        const { token } = await newSession(request, dependente())
        const empty = await request.post(`${API}/triage`, { data: { answers: [] }, headers: bearer(token) })
        expect(empty.status()).toBe(204)
        const me = await (await request.get(`${API}/me`, { headers: bearer(token) })).json()
        expect(me.has_triage).toBe(false)
        const real = await request.post(`${API}/triage`, { data: { answers: [firstChoiceAnswer(await questions(request, token))] }, headers: bearer(token) })
        expect(real.status()).toBe(201)
    })

    test('PUT vazio: 400 INVALID_TRIAGE e a triagem guardada permanece', async ({ request }) => {
        const { token } = await newSession(request, dependente())
        await request.post(`${API}/triage`, { data: { answers: [firstChoiceAnswer(await questions(request, token))] }, headers: bearer(token) })
        const put = await request.put(`${API}/triage`, { data: { answers: [] }, headers: bearer(token) })
        expect(put.status()).toBe(400)
        expect((await put.json()).code).toBe('INVALID_TRIAGE')
        expect((await (await request.get(`${API}/me`, { headers: bearer(token) })).json()).has_triage).toBe(true)
    })

    test('AGE_UNDER_18 como resposta: 400', async ({ request }) => {
        const { token } = await newSession(request, dependente())
        const qs = await questions(request, token)
        const age = qs.find((q) => q.options.some((o) => o.code.startsWith('AGE_'))) ?? qs.find((q) => q.question_type === 'single_choice')!
        const res = await request.post(`${API}/triage`, { data: { answers: [{ question_id: age.id, values: ['AGE_UNDER_18'] }] }, headers: bearer(token) })
        expect(res.status()).toBe(400)
        expect((await res.json()).code).toBe('INVALID_TRIAGE')
    })

    test('texto livre com 1000 emojis: 201', async ({ request }) => {
        const { token } = await newSession(request, dependente())
        const free = (await questions(request, token)).find((q) => q.question_type === 'free_text')!
        const res = await request.post(`${API}/triage`, { data: { answers: [{ question_id: free.id, values: ['😀'.repeat(1000)] }] }, headers: bearer(token) })
        expect(res.status(), await res.text()).toBe(201)
    })

    test('psicólogo não envia triagem: 403', async ({ request }) => {
        const { token } = await newSession(request, psicologo())
        const res = await request.post(`${API}/triage`, { data: { answers: [] }, headers: bearer(token) })
        expect(res.status()).toBe(403)
        expect((await res.json()).code).toBe('FORBIDDEN')
    })
})

test.describe('/triages e auditoria', () => {
    test('dependente 403; admin 200 sem real_name nem e-mail; psicólogo 200', async ({ request }) => {
        const dep = await newSession(request, dependente())
        await request.post(`${API}/triage`, { data: { answers: [firstChoiceAnswer(await questions(request, dep.token))] }, headers: bearer(dep.token) })

        expect((await request.get(`${API}/triages`, { headers: bearer(dep.token) })).status()).toBe(403)

        const admin = await loginToken(request, ADMIN.email, ADMIN.password)
        const adminRes = await request.get(`${API}/triages?size=5`, { headers: bearer(admin) })
        expect(adminRes.status()).toBe(200)
        const raw = await adminRes.text()
        expect(raw).not.toContain('real_name')
        expect(raw).not.toContain(dep.user.email)
        expect(raw).not.toContain('"email"')
        expect(JSON.parse(raw).items.length).toBeGreaterThan(0)

        const psi = await newSession(request, psicologo())
        expect((await request.get(`${API}/triages`, { headers: bearer(psi.token) })).status()).toBe(200)
    })

    test('TRIAGE_VIEWED em /admin/audit e em /me/access-log (sem actor_id); psicólogo 403 em /admin/audit', async ({ request }) => {
        const dep = await newSession(request, dependente())
        const posted = await (await request.post(`${API}/triage`, { data: { answers: [firstChoiceAnswer(await questions(request, dep.token))] }, headers: bearer(dep.token) })).json()
        const depId = (await (await request.get(`${API}/me`, { headers: bearer(dep.token) })).json()).id

        const admin = await loginToken(request, ADMIN.email, ADMIN.password)
        const read = await request.get(`${API}/triages/${posted.id}`, { headers: bearer(admin) })
        expect(read.status()).toBe(200)

        const audit = await request.get(`${API}/admin/audit?subject_user_id=${depId}&action=TRIAGE_VIEWED`, { headers: bearer(admin) })
        expect(audit.status()).toBe(200)
        const entries = (await audit.json()).items
        expect(entries).toHaveLength(1)
        expect(entries[0]).toMatchObject({ action: 'TRIAGE_VIEWED', subject_user_id: depId, entity_id: posted.id })
        expect(entries[0].details.actor_role).toBe('admin')

        // a visão do titular nunca revela quem leu (LGPD art. 18): só o papel
        const log = await request.get(`${API}/me/access-log`, { headers: bearer(dep.token) })
        expect(log.status()).toBe(200)
        const logBody = await log.json()
        const items = logBody.items ?? logBody
        expect(items.length).toBeGreaterThanOrEqual(1)
        expect(items[0].action).toBe('TRIAGE_VIEWED')
        expect(items[0].actor_role).toBe('admin')
        expect(JSON.stringify(logBody)).not.toContain('actor_id')

        const psi = await newSession(request, psicologo())
        const denied = await request.get(`${API}/admin/audit`, { headers: bearer(psi.token) })
        expect(denied.status()).toBe(403)
        expect((await denied.json()).code).toBe('FORBIDDEN')
    })

    // Regra do projeto: só psicólogo VALIDADO lê triagem. A validação ainda não existe (is_validate nunca vira true
    // e TriageReadController libera qualquer psicólogo), então hoje o back devolve 200. test.fail() mantém a suíte
    // verde enquanto a falha é conhecida; quando a regra for implementada o teste "passa" e o Playwright acusa
    // que a marca deve ser removida.
    test('FALHA CONHECIDA: psicólogo recém-cadastrado recebe 403 em /triages', async ({ request }) => {
        test.fail(true, 'Falha conhecida: a validação de psicólogo ainda não existe; hoje qualquer psicólogo lê triagens (200)')
        const psi = await newSession(request, psicologo())
        const res = await request.get(`${API}/triages`, { headers: bearer(psi.token) })
        expect(res.status()).toBe(403)
    })
})

test.describe('documentação', () => {
    test('Swagger UI abre em /swagger-ui/index.html', async ({ request }) => {
        const res = await request.get(`${API}/swagger-ui/index.html`, { headers: { 'X-Forwarded-For': nextIp() } })
        expect(res.status()).toBe(200)
        expect(res.headers()['content-type']).toContain('text/html')
        expect(await res.text()).toContain('swagger-ui')
    })
})
