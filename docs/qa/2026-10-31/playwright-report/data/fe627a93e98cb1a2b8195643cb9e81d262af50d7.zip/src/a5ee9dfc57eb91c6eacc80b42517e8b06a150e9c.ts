import type { APIRequestContext, APIResponse } from '@playwright/test'

export const API = process.env.API_URL ?? 'http://localhost:8080'
export const ADMIN = { email: 'admin@plad.dev', password: 'admin-e2e-senha-123' }
export const PASSWORD = 'senha-e2e-123'

// Identificador único da execução: o banco guarda estado entre execuções
export const RUN = Date.now().toString(36)
let seq = 0
export const uniq = (prefix: string) => `${prefix}-${RUN}-${++seq}`

// O backend confia em X-Forwarded-For vindo de loopback; um IP novo por chamada evita o limite de 5/min por IP
let ipSeq = Math.floor(Math.random() * 200) * 200
export function nextIp(): string {
    ipSeq += 1
    return `10.${(ipSeq >> 8) & 255}.${ipSeq & 255}.${(Math.random() * 250 + 1) | 0}`
}

/** Data (yyyy-MM-dd) em America/Sao_Paulo, que é o "hoje" do backend, somada a `days` dias */
export function saoPauloDate(yearsAgo: number, plusDays = 0): string {
    const now = new Date()
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' })
        .format(now)
        .split('-')
        .map(Number)
    const d = new Date(Date.UTC(parts[0] - yearsAgo, parts[1] - 1, parts[2] + plusDays))
    return d.toISOString().slice(0, 10)
}

export interface NewUser {
    real_name: string
    email: string
    password: string
    birth_date: string
    gender: string
    type_user: string
    credential_type?: string
    crm_crp_number?: string
    graduate?: string
}

export function dependente(over: Partial<NewUser> = {}): NewUser {
    return {
        real_name: 'Dependente E2E',
        email: `${uniq('dep')}@plad.dev`,
        password: PASSWORD,
        birth_date: '1990-05-20',
        gender: 'nao_binario',
        type_user: 'dependente',
        ...over,
    }
}

let crpSeq = Math.floor(Math.random() * 90_000)
export function psicologo(over: Partial<NewUser> = {}): NewUser {
    crpSeq += 1
    return {
        real_name: 'Psicologa E2E',
        email: `${uniq('psi')}@plad.dev`,
        password: PASSWORD,
        birth_date: '1985-03-10',
        gender: 'feminino',
        type_user: 'psicologo',
        credential_type: 'CRP',
        crm_crp_number: `06/${100000 + crpSeq}${Date.now() % 1000}`,
        graduate: 'Psicologia - USP',
        ...over,
    }
}

export function register(request: APIRequestContext, body: NewUser, ip = nextIp()): Promise<APIResponse> {
    return request.post(`${API}/auth/register`, { data: body, headers: { 'X-Forwarded-For': ip } })
}

export async function loginToken(request: APIRequestContext, email: string, password = PASSWORD): Promise<string> {
    const res = await request.post(`${API}/auth/login`, { data: { email, password }, headers: { 'X-Forwarded-For': nextIp() } })
    if (res.status() !== 200) throw new Error(`login ${email}: HTTP ${res.status()} ${await res.text()}`)
    return (await res.json()).token
}

/** Cria a conta e devolve o token */
export async function newSession(request: APIRequestContext, user: NewUser): Promise<{ token: string; user: NewUser }> {
    const res = await register(request, user)
    if (res.status() !== 201) throw new Error(`register ${user.email}: HTTP ${res.status()} ${await res.text()}`)
    return { token: await loginToken(request, user.email, user.password), user }
}

export const bearer = (token: string, ip = nextIp()) => ({ Authorization: `Bearer ${token}`, 'X-Forwarded-For': ip })

export interface Question {
    id: number
    question_text: string
    question_type: 'single_choice' | 'multi_choice' | 'free_text'
    options: { code: string; label: string }[]
    display_order: number
}

export async function questions(request: APIRequestContext, token: string): Promise<Question[]> {
    const res = await request.get(`${API}/triage/questions`, { headers: bearer(token) })
    return res.json()
}

/** Uma resposta válida para a primeira pergunta de escolha */
export function firstChoiceAnswer(qs: Question[]) {
    const q = qs.find((x) => x.question_type !== 'free_text')!
    return { question_id: q.id, values: [q.options[0].code] }
}
